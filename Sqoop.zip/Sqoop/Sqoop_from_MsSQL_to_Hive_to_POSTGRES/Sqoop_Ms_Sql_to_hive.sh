

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table HumanResources.Employee --hive-import  --hive-database adventureworks --hive-table Employee -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table HumanResources.EmployeeDepartmentHistory --hive-import  --hive-database adventureworks --hive-table EmployeeDepartmentHistory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table HumanResources.EmployeePayHistory --hive-import  --hive-database adventureworks --hive-table EmployeePayHistory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table HumanResources.JobCandidate --hive-import  --hive-database adventureworks --hive-table JobCandidate -m 1


sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table HumanResources.Shift --hive-import  --hive-database adventureworks --hive-table Shift -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.Address --hive-import  --hive-database adventureworks --hive-table Address -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.AddressType --hive-import  --hive-database adventureworks --hive-table AddressType -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.BusinessEntity --hive-import  --hive-database adventureworks --hive-table BusinessEntity -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.BusinessEntityAddress --hive-import  --hive-database adventureworks --hive-table BusinessEntityAddress -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.BusinessEntityContact --hive-import  --hive-database adventureworks --hive-table BusinessEntityContact -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.ContactType --hive-import  --hive-database adventureworks --hive-table ContactType -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.CountryRegion --hive-import  --hive-database adventureworks --hive-table CountryRegion -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.EmailAddress --hive-import  --hive-database adventureworks --hive-table EmailAddress -m 1


sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.Password --hive-import  --hive-database adventureworks --hive-table Password -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.Person --hive-import  --hive-database adventureworks --hive-table Person -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.PersonPhone --hive-import  --hive-database adventureworks --hive-table PersonPhone -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.PhoneNumberType --hive-import  --hive-database adventureworks --hive-table PhoneNumberType -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Person.BusinessEntityContact --hive-import  --hive-database adventureworks --hive-table StateProvince -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.BillOfMaterials --hive-import  --hive-database adventureworks --hive-table BillOfMaterials -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.Culture --hive-import  --hive-database adventureworks --hive-table Culture -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.Document --hive-import  --hive-database adventureworks --hive-table Document -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.Illustration --hive-import  --hive-database adventureworks --hive-table Illustration -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.Location --hive-import  --hive-database adventureworks --hive-table Location -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.Product --hive-import  --hive-database adventureworks --hive-table Product -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductCategory --hive-import  --hive-database adventureworks --hive-table ProductCategory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Purchasing.ProductVendor --hive-import  --hive-database adventureworks --hive-table ProductVendor -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Purchasing.PurchaseOrderDetail --hive-import  --hive-database adventureworks --hive-table PurchaseOrderDetail -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Purchasing.PurchaseOrderHeader --hive-import  --hive-database adventureworks --hive-table PurchaseOrderHeader -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Purchasing.ShipMethod --hive-import  --hive-database adventureworks --hive-table ShipMethod -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Purchasing.Vendor --hive-import  --hive-database adventureworks --hive-table Vendor -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.CountryRegionCurrency --hive-import  --hive-database adventureworks --hive-table CountryRegionCurrency -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.CreditCard --hive-import  --hive-database adventureworks --hive-table CreditCard -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.Currency --hive-import  --hive-database adventureworks --hive-table Currency -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.CurrencyRate --hive-import  --hive-database adventureworks --hive-table CurrencyRate -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.Customer --hive-import  --hive-database adventureworks --hive-table Customer -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.PersonCreditCard --hive-import  --hive-database adventureworks --hive-table PersonCreditCard -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SalesOrderDetail --hive-import  --hive-database adventureworks --hive-table SalesOrderDetail -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SalesOrderHeader --hive-import  --hive-database adventureworks --hive-table SalesOrderHeader -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SalesOrderHeaderSalesReason --hive-import  --hive-database adventureworks --hive-table SalesOrderHeaderSalesReason -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SalesPerson --hive-import  --hive-database adventureworks --hive-table SalesPerson -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SalesPersonQuotaHistory --hive-import  --hive-database adventureworks --hive-table SalesPersonQuotaHistory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SalesReason --hive-import  --hive-database adventureworks --hive-table SalesReason -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SalesTaxRate --hive-import  --hive-database adventureworks --hive-table SalesTaxRate -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SalesTerritory --hive-import  --hive-database adventureworks --hive-table SalesTerritory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SalesTerritoryHistory --hive-import  --hive-database adventureworks --hive-table SalesTerritoryHistory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.ShoppingCartItem --hive-import  --hive-database adventureworks --hive-table ShoppingCartItem -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SpecialOffer --hive-import  --hive-database adventureworks --hive-table SpecialOffer -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.SpecialOfferProduct --hive-import  --hive-database adventureworks --hive-table SpecialOfferProduct -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Sales.Store --hive-import  --hive-database adventureworks --hive-table Store -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductCostHistory --hive-import  --hive-database adventureworks --hive-table ProductCostHistory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductDescription --hive-import  --hive-database adventureworks --hive-table ProductDescription -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductDocument --hive-import  --hive-database adventureworks --hive-table ProductDocument -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductInventory --hive-import  --hive-database adventureworks --hive-table ProductInventory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductListPriceHistory --hive-import  --hive-database adventureworks --hive-table ProductListPriceHistory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductModel --hive-import  --hive-database adventureworks --hive-table ProductModel -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductModelIllustration --hive-import  --hive-database adventureworks --hive-table ProductModelIllustration -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductModelProductDescriptionCulture --hive-import  --hive-database adventureworks --hive-table ProductModelProductDescriptionCulture -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductPhoto --hive-import  --hive-database adventureworks --hive-table ProductPhoto -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductProductPhoto --hive-import  --hive-database adventureworks --hive-table ProductProductPhoto -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductReview --hive-import  --hive-database adventureworks --hive-table ProductReview -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductSubcategory --hive-import  --hive-database adventureworks --hive-table ProductSubcategory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ScrapReason --hive-import  --hive-database adventureworks --hive-table ScrapReason -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.TransactionHistory --hive-import  --hive-database adventureworks --hive-table TransactionHistory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.TransactionHistoryArchive --hive-import  --hive-database adventureworks --hive-table TransactionHistoryArchive -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.UnitMeasure --hive-import  --hive-database adventureworks --hive-table UnitMeasure -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.WorkOrder --hive-import  --hive-database adventureworks --hive-table WorkOrder -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.WorkOrderRouting --hive-import  --hive-database adventureworks --hive-table WorkOrderRouting -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.BillOfMaterials --hive-import  --hive-database adventureworks --hive-table BillOfMaterials -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.Culture --hive-import  --hive-database adventureworks --hive-table Culture -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.Document --hive-import  --hive-database adventureworks --hive-table Document -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.Illustration --hive-import  --hive-database adventureworks --hive-table Illustration -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.Location --hive-import  --hive-database adventureworks --hive-table Location -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.Product --hive-import  --hive-database adventureworks --hive-table Product -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductCategory --hive-import  --hive-database adventureworks --hive-table ProductCategory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductCostHistory --hive-import  --hive-database adventureworks --hive-table ProductCostHistory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductDescription --hive-import  --hive-database adventureworks --hive-table ProductDescription -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductDocument --hive-import  --hive-database adventureworks --hive-table ProductDocument -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductInventory --hive-import  --hive-database adventureworks --hive-table ProductInventory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductListPriceHistory --hive-import  --hive-database adventureworks --hive-table ProductListPriceHistory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductModel --hive-import  --hive-database adventureworks --hive-table ProductModel -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductModelIllustration --hive-import  --hive-database adventureworks --hive-table ProductModelIllustration -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductModelProductDescriptionCulture --hive-import  --hive-database adventureworks --hive-table ProductModelProductDescriptionCulture -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductPhoto --hive-import  --hive-database adventureworks --hive-table ProductPhoto -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductProductPhoto --hive-import  --hive-database adventureworks --hive-table ProductProductPhoto -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductReview --hive-import  --hive-database adventureworks --hive-table ProductReview -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ProductSubcategory --hive-import  --hive-database adventureworks --hive-table ProductSubcategory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.ScrapReason --hive-import  --hive-database adventureworks --hive-table ScrapReason -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.TransactionHistory --hive-import  --hive-database adventureworks --hive-table TransactionHistory -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.TransactionHistoryArchive --hive-import  --hive-database adventureworks --hive-table TransactionHistoryArchive -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.UnitMeasure --hive-import  --hive-database adventureworks --hive-table UnitMeasure -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.WorkOrder --hive-import  --hive-database adventureworks --hive-table WorkOrder -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table Production.WorkOrderRouting --hive-import  --hive-database adventureworks --hive-table WorkOrderRouting -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table dbo.AWBuildVersion --hive-import  --hive-database adventureworks --hive-table AWBuildVersion -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table dbo.DatabaseLog --hive-import  --hive-database adventureworks --hive-table DatabaseLog -m 1

sqoop-import --driver com.microsoft.sqlserver.jdbc.SQLServerDriver --connect 'jdbc:sqlserver://10.10.6.2:32433;database=AdventureWorks2014'  --username sa --password Netus3r! --table dbo.ErrorLog --hive-import  --hive-database adventureworks --hive-table ErrorLog -m 1


