# Sqoop
Import data MySql to Hive
